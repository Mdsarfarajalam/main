"use strict";
exports.__esModule = true;
exports.DeviceTypes = void 0;
var DeviceTypes;
(function (DeviceTypes) {
    DeviceTypes[DeviceTypes["DESKTOP"] = 0] = "DESKTOP";
    DeviceTypes[DeviceTypes["MOBILE"] = 1] = "MOBILE";
})(DeviceTypes = exports.DeviceTypes || (exports.DeviceTypes = {}));
;
