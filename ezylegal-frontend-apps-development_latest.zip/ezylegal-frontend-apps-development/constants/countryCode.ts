const countryCode = [{
    value: '91',
    label: '+91'
}, {
    value: '1',
    label: '+1'
}];

export default countryCode;