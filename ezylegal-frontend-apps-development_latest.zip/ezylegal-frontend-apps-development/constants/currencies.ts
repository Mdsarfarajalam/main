const countries: any = {
    'in': {
        symbol: "&#8377;",
        currency: "INR"
    },
    'us': {
        symbol: "&#36;",
        currency: "INR"
    }
};

export default countries;