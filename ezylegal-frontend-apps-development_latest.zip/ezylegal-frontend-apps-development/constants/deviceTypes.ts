export enum DeviceTypes{
    "DESKTOP",
    "MOBILE"
};