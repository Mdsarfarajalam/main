"use strict";
exports.__esModule = true;
exports.emailAddress = exports.contactNumber = void 0;
exports.contactNumber = "+91-85 8888 7480";
exports.emailAddress = "contact@ezylegal.in";
