export const contactNumber: string = "+91-85 8888 7480";
export const emailAddress: string = "contact@ezylegal.in";