import { FC } from 'react';
import { GetStaticProps } from 'next';
import { promises as fs } from 'fs';
import Link from 'next/link';
import Head from 'next/head';

import {
  CATEGORIES_FILE,
  MENUS_FILE,
  Home_File,
  FOOTER_FILE,
} from '../constants/file-paths';
import Menus from '../dtos/Menus.dto';
import MainLayout from '../components/MainLayout';
import CorneredBox from '../components/CorneredBox';
import Text from '../styled/Text';
import GetQouteSection from '../components/GetQouteSection';
import KeenSlider, { KeenSlide } from '../components/KeenSlider';
import ShadowCard from '../styled/ShadowCard';
import Spacer from '../styled/Spacer';
import Button from '../styled/Button';
import HomeCategoryBox from '../components/HomeCategoryBox';
import CircledText from '../styled/CircledText';
import FooterDefinition from '../dtos/Footer.dto';

const Home: FC<any> = ({ menus, HomePageData, footer }) => {
  const {
    page: { home_page },
  } = HomePageData;
  return (
    <MainLayout
      menus={menus}
      headerBgColorBack="skyBlue"
      isHome
      footer={footer}
    >
      <Head>
        <title>Home &#8211; EzyLegal</title>
      </Head>
      <CorneredBox bgColor="skyBlue" bgColorBack="secondary">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-12 col-md-6">
              <Text fontSize="xxxl" fontFamily="montserrat" weight="bold">
                {home_page.banner.content.title}
              </Text>
              <Spacer size={20} direction="vertical" />
              <Text fontSize="xl" weight="semibold" color="gray-900">
                {home_page.banner.content.summary}
              </Text>
              <Spacer size={50} direction="vertical" />
              {home_page.banner.highlightedCategories.map(
                (el: any, i: number) => (
                  <div key={i}>
                    <Link href={`/category/${el.link}`}>
                      <a>
                        <Button
                          size="lg"
                          rounded
                          className="mb-2"
                          style={{
                            minWidth: '270px',
                          }}
                        >
                          {el.name}
                        </Button>
                      </a>
                    </Link>
                    <Spacer size={20} direction="horizontal" key={i + 1} />
                  </div>
                )
              )}
            </div>
            <div className="col-12 col-md-6">
              <img
                src={home_page.banner.content.image?.sourceUrl}
                className="Banner1"
              />
            </div>
          </div>
        </div>
      </CorneredBox>
      <GetQouteSection bgColorBack="lightSkyBlue" />
      <CorneredBox
        bgColor="lightSkyBlue"
        bgColorBack="white"
        paddingTop="70px"
        paddingBottom="70px"
      >
        <div className="container">
          <div className="row">
            {home_page.businessMatrix.map((el: any, i: number) => (
              <div className="col-12 col-md-4 text-center" key={i}>
                <Text fontFamily="montserrat" weight="bold" fontSize="xxxl">
                  {el.counter} <br />
                  {el.heading}
                </Text>
                <Text>{el.content}</Text>
              </div>
            ))}
          </div>
        </div>
      </CorneredBox>
      <section>
        <div className="container">
          <Spacer direction="vertical" size={50} />
          {home_page.cardlist.map((category: any, i: number) => (
            <HomeCategoryBox key={i} category={category} />
          ))}
        </div>
      </section>
      <CorneredBox
        bgColor="skyBlue"
        bgColorBack="white"
        paddingTop="70px"
        paddingBottom="70px"
      >
        <div className="container">
          <div className="row">
            <div className="col-12 text-center">
              <Text fontSize="xxxl" fontFamily="montserrat" weight="bold">
                Why Choose Us
              </Text>
              <Spacer direction="vertical" size={20} />
            </div>
            {home_page.whyChooseUs.map((el: any, i: number) => (
              <div className="col-12 col-md-4" key={i}>
                <div className="row">
                  <div className="col-auto">
                    <CircledText fontSize="lg" weight="semibold">
                      {i + 1}
                    </CircledText>
                  </div>
                  <div className="col">
                    <Text fontSize="lg" weight="semibold">
                      {el.title}
                    </Text>
                    <Text fontSize="base" weight="semibold">
                      {el.description}
                    </Text>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CorneredBox>
      <CorneredBox
        bgColor="white"
        bgColorBack="secondary"
        paddingBottom="70px"
        paddingTop="70px"
      >
        <div className="container">
          <Text
            fontFamily="montserrat"
            fontSize="xxxl"
            className="text-center"
            weight="bold"
          >
            {home_page.testimonialData.testimonialHeading}
          </Text>
          <Text className="text-center" fontSize="lg" weight="semibold">
            {home_page.testimonialData.testimonialSubHeading}
          </Text>
          <KeenSlider
            loop={true}
            slidesPerView={1}
            showArrows={true}
            spacing={20}
            slideTimer={2000}
            breakpoints={{
              '(min-width: 1200px)': {
                slidesPerView: 2,
              },
            }}
          >
            {home_page.testimonialData.testimonials.map(
              (el: any, i: number) => (
                <KeenSlide key={i}>
                  <div className="text-center">
                    <img
                      src={el.profileImage?.sourceUrl}
                      alt="image"
                      className="circle"
                      width="100"
                    />
                    <Spacer direction="vertical" size={20} />
                    <Text color="black" fontSize="base">
                      {el.summary}
                    </Text>
                    <Spacer direction="vertical" size={8} />
                    <Text fontSize="lg">{el.name}</Text>
                    <Spacer direction="vertical" size={8} />
                    <Text color="gray-500" fontSize="md">
                      {el.designation}
                    </Text>
                  </div>
                </KeenSlide>
              )
            )}
          </KeenSlider>
        </div>
      </CorneredBox>
    </MainLayout>
  );
};

export const getStaticProps: GetStaticProps = async () => {
  // fetch menus
  const menuData = await fs.readFile(MENUS_FILE, { encoding: 'utf-8' });
  const menus: Menus = JSON.parse(menuData);

  // fetch categories
  // const categoriesData = await fs.readFile(CATEGORIES_FILE, { encoding: 'utf-8' });
  // const categories: Category[] = JSON.parse(categoriesData);
  // Fetched Home page data
  const Homepage = await fs.readFile(Home_File, { encoding: 'utf-8' });
  const HomePageData: any = JSON.parse(Homepage);

  const footerData = await fs.readFile(FOOTER_FILE, { encoding: 'utf-8' });
  const footer: FooterDefinition = JSON.parse(footerData);

  return {
    props: {
      menus,
      HomePageData,
      footer,
    },
  };
};

export default Home;
