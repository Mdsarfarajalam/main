import backendApi from '../../api/backendApi';
import { CREATE_ORDER_QUERY } from '../../constants/queries/order';
import {CREATE_USER_QUERY, Update_USER_Mutation} from '../../constants/queries/user';
import { errorToast } from '../../utils/toasts';
import { setLoggedInUser } from '../loggedInUser/loggedInUser.actions';
import { AppDispatch } from '../store';
import { SET_CURRENT_ORDER } from './currentOrder.types';
import loggedInUserReducer from "../loggedInUser/loggedInUser.reducer";

export const setOrder = (data: any) => (dispatch: AppDispatch) => {
    dispatch({
        type: SET_CURRENT_ORDER,
        payload: data
    });
};

export const checkoutOrderCreate = async (userRes: any, cart: any, tax:any) => {
    console.log("Requested order creation");
    let total : number = 0
    cart.items.forEach((el:any) =>{
        total += parseFloat(el.salePrice);
    });
    const taxTotal = Math.ceil((total / 100) * tax?.rate);
    const orderRes = await backendApi.post('/', {
        query: CREATE_ORDER_QUERY,
        variables: {
            user: userRes._id,
            category_id: cart.items[0].category.id,
            total_amount: taxTotal + total,
            tax: taxTotal,
            subtotal: total,
            discount: 0,
            currency: "INR",
            products: cart.items.map((el:any) => {
                return {
                    product_id: el.id,
                    product_name: el.name,
                    assigned_user: userRes._id,
                    amount: parseFloat(el.salePrice),
                }
            })
        }
    });
    console.log(orderRes);
    return orderRes;
}

export const checkout = (user: any, cart:any,tax:any, cb: Function) => async (dispatch: AppDispatch) => {
    try {
        const userRes = await backendApi.post('/', {
            query: CREATE_USER_QUERY,
            variables: {
                email: user.email,
                name: user.name,
                mobile: parseFloat(user.mobile),
                countryCode: parseInt(user.countryCode),
                type: user.type
            }
        });
        if (userRes.data.errors?.length) throw new Error(userRes.data.errors[0].message);
        dispatch(setLoggedInUser(userRes.data.data.createUser));
        // const orderRes = await checkoutOrderCreate(userRes.data.data.createUser, cart, tax);
        // dispatch(setOrder(orderRes.data));
        cb();
    } catch (error) {
        errorToast(error.message);
        console.log(error)
    }
};


export const updateAndCheckout = (user: any, loggedInUserData: any, cart:any,tax:any, cb: Function) => async (dispatch: AppDispatch) => {
    try {
        console.log("User data", loggedInUserData);
        const userRes = await backendApi.post('/', {
            query: Update_USER_Mutation,
            variables: {
                _id: loggedInUserData._id,
                country_code: user.countryCode? parseInt(user.countryCode) : loggedInUserData.country_code,
                email: user.email,
                mobile: parseFloat(user.mobile),
                name: user.name,
                type: user.type,
                gst: loggedInUserData.gst ? loggedInUserData.gst : "",
                company: loggedInUserData.companyName ? loggedInUserData.companyName : "",
                city: loggedInUserData.city ? loggedInUserData.city : "",
                state: loggedInUserData.state ? loggedInUserData.state : ""
            }
        });
        if (userRes.data.errors?.length) throw new Error(userRes.data.errors[0].message);
        console.log("User res is", userRes);
        dispatch(setLoggedInUser(userRes.data.data.updateUser));
        // const orderRes = await checkoutOrderCreate(userRes.data.data.updateUser, cart, tax);
        // dispatch(setOrder(orderRes.data));
        cb();
    } catch (error) {
        errorToast(error.message);
        console.log(error)
    }
};

export const createNewOrder = (user: any, cart: any, tax: any, cb: any) => async (dispatch: AppDispatch) => {
    const orderRes = await checkoutOrderCreate(user, cart, tax);
    dispatch(setOrder(orderRes.data));
    cb();

}