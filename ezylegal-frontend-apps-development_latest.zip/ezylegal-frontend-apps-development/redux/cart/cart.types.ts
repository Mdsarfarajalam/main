export const ADD_ITEMS = 'ADD_ITEMS';
export const ADD_SINGLE_ITEM = 'ADD_SINGLE_ITEM';
export const EMPTY_CART = 'EMPTY_CART';