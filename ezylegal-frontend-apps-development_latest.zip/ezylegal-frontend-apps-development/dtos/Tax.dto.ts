export default interface Tax {
    country:    string;
    id:         string;
    name:       string;
    rate:       string;
}
