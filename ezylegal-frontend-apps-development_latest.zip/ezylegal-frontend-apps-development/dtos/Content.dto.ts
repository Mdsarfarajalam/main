import Image from "./Image.dto";

export default interface Content {
    description: string;
    title:       string;
    icon:        Image;
}