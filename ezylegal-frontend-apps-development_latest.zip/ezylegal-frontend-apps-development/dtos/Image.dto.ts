export default interface Image {
    databaseId: number;
    sourceUrl:  string;
    title:      string;
}