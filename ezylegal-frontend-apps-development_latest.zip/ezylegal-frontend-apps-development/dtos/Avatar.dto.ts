export default interface Avatar {
    url: string;
};