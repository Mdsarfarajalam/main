import Image from "./Image.dto";

export default interface ProductFeature{
    description: string;
    icon: Image;
}