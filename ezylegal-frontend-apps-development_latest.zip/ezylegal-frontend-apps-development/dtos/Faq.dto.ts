export default interface Faq {
    answer:   string;
    question: string;
}