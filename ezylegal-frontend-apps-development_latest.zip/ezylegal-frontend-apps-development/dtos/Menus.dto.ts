import MenuItem from './MenuItem.dto';

export default interface Menus {
    footer1: MenuItem[];
    header:  MenuItem[];
}
