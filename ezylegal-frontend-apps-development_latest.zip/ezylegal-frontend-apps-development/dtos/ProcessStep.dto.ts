export default interface ProcessStep {
    order: number;
    step:  string;
};