export default interface VerifiedExpertSection{
    number: string;
    label: string;
    text: string;
}