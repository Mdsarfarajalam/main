import Image from "./Image.dto";

export default interface ProductCharacteristics{
    label: string;
    icon: Image;
}