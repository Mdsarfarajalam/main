export default interface Seo {
    robot:          string;
    keywords:       string;
    description:    string;
}
