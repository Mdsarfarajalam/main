import { FC } from 'react';
import Link from 'next/link';
import Zendesk from 'react-zendesk';

import MenuItem from '../../dtos/MenuItem.dto';
import {
  FloatingButton,
  Footer as StyledFooter,
  Footer2Menu,
  FooterMenu,
  FooterTop,
} from './Footer.styled';
import Text from '../../styled/Text';
import Spacer from '../../styled/Spacer';
import Button from '../../styled/Button';
import Divider from '../../styled/Divider';
import {
  contactNumber,
  emailAddress,
} from '../../constants/contactInformation';
import { DeviceTypes } from '../../constants/deviceTypes';
import WhatsappFooterButton from '../WhatsappFooterButton/WhatsappFooterButton';
import FooterDefinition from '../../dtos/Footer.dto';

const ZENDESK_KEY = 'cda34b4e-33b3-423c-9ced-053740ee0306';

interface FooterProps {
  footer1Menu?: MenuItem[];
  footer2Menu?: MenuItem[];
  isHome?: boolean;
  device: DeviceTypes;
  footer?: FooterDefinition;
}

const FooterJumpTop = () => {
  return(
      <div style={{
        position: "absolute",
        display: "block",
        width: "60px",
        height: "60px",
        borderRadius: "50%",
        marginTop: "-70px",
        left: "50%",
        backgroundColor: "#396aeb",
        cursor: "pointer"
      }} className="d-flex flex-column justify-content-center align-items-center"
           onClick={() => {
             document.body.scrollTop = document.documentElement.scrollTop = 0;
           }}>
        <Text fontSize="sm" weight="bold" color="white"> ^ </Text>
        <Text weight="bold" color="white"> TOP </Text>
      </div>
  );
}

const Footer: FC<FooterProps> = ({ footer1Menu, isHome, device, footer }) => {
  return (
    <>
      {isHome ? (
        <FooterTop>
          <FooterJumpTop />
          <div className="container">
            <div className="row align-items-center">
              <div className="col-12 col-md">
                <img src="/images/footer-logo.svg" alt="Logo" />
              </div>
              <div className="col-12 col-md" />
              <div className="col-12 col-md-5">
                <Text
                  fontSize="lg"
                  fontFamily="montserrat"
                  color="white"
                  weight="bold"
                >
                  Get Useful tips and info from our Newsletter
                </Text>
                <Spacer size={20} direction="vertical" />
                <div className="d-flex">
                  <input className="form-control" placeholder="Your Email Id" />
                  <Spacer direction="horizontal" size={15} />
                  <Button size="md" cornered>
                    Signup
                  </Button>
                </div>
              </div>
            </div>
            <Divider color="white" margin="40px" />
            <div className="row">
              <div className="col-12 col-md-5">
                <Text color="white" fontSize="lg">
                  {footer?.footer_leftcontainer?.about.heading}
                </Text>
                <Text color="white" fontSize="sm">
                  {footer?.footer_leftcontainer?.about.description}
                </Text>
                <Spacer size={20} direction="vertical" />
                {footer?.footer_rightcontainer?.sections?.sectionlinks
                  ?.length ? (
                  <FooterMenu>
                    {footer.footer_rightcontainer.sections.sectionlinks.map(
                      (menu) => (
                        <li key={`link-${menu.name}`}>
                          <Link href={menu.link}>
                            <a>
                              <Text fontSize="sm" color="white">
                                {menu.name}
                              </Text>
                            </a>
                          </Link>
                        </li>
                      )
                    )}
                  </FooterMenu>
                ) : null}
              </div>
              <div className="col-12 col-md-7">
                <div className="row justify-content-between">
                  <div className="col-12 col-md-auto">
                    <Text color="white" fontSize="lg">
                      {footer?.footer_rightcontainer.secondSections.heading}
                    </Text>
                    <Footer2Menu>
                      {footer?.footer_rightcontainer.secondSections.sectionlinks.map(
                        (item: any) => {
                          return (
                            <li>
                              <Link href={item.link}>
                                <a>
                                  <Text color="white" fontSize="sm">
                                    {item.name}
                                  </Text>
                                </a>
                              </Link>
                            </li>
                          );
                        }
                      )}
                    </Footer2Menu>
                  </div>
                  <div className="col-12 col-md-auto">
                    <Text color="white" fontSize="lg">
                      Socials
                    </Text>
                    <FooterMenu>
                      {footer?.footer_leftcontainer.social.map((social: any) => {
                        let iconSrc = '';
                        switch (social.name) {
                          case 'Twitter':
                            iconSrc = '/icons/twitter.svg';
                            break;
                          case 'LinkedIn':
                            iconSrc = '/icons/linkedin.svg';
                            break;
                          case 'Instagram':
                            iconSrc = '/icons/instagram.svg';
                            break;
                          case 'Facebook':
                            iconSrc = '/icons/facebook.svg';
                            break;
                        }
                        return (
                          <li>
                            <Link href={social.link}>
                              <a>
                                <img
                                  src={iconSrc}
                                  width={20}
                                  height={20}
                                  alt={social.alttext}
                                />
                              </a>
                            </Link>
                          </li>
                        );
                      })}
                    </FooterMenu>
                    <Spacer size={40} direction="vertical" />
                    <Text color="white" fontSize="lg">
                      Contact Us
                    </Text>
                    <Link href={'mailto:' + emailAddress}>
                      <a>
                        <Text color="white" fontSize="sm" block>
                          <img
                            src="/icons/email_24px.svg"
                            width="16"
                            alt="email"
                            className="mr-2"
                          />
                          {emailAddress}
                        </Text>
                      </a>
                    </Link>
                    <Link href={'tel:' + contactNumber}>
                      <a>
                        <Text color="white" fontSize="sm" block>
                          <img
                            src="/icons/phone_24px.svg"
                            width="16"
                            alt="phone"
                            className="mr-2"
                          />
                          {contactNumber}
                        </Text>
                      </a>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </FooterTop>
      ) : null}
      <StyledFooter>
        {!isHome ? <FooterJumpTop /> : null}
        <div className="container">
          <div className="row">
            <div className="col-12 col-md-8">
              <Text color="white" fontSize="sm">
                © 2021 Neo Online Ventures Pvt Ltd. All rights reserved.
              </Text>
              <Text color="white" fontSize="sm">
                ezyLegal is not a law firm, or a substitute for a lawyer or law
                firm. We are also not a "lawyer referral service". Use of this
                website will be at the sole risk of the user. Use of any service
                will not create any lawyer-client relationship.
                <Spacer direction="vertical" size={15} />
                ezyLegal will not be liable for any consequence of any action
                taken by the user relying on information or services provided
                under this website. In cases where the user has any legal
                issues, he/she in all cases must seek independent legal advice.
                <Spacer direction="vertical" size={15} />
                Use of our products and services are governed by our
                <Link href="/termsandconditions"> Terms of Use </Link> and
                <Link href="/privacy"> Privacy Policy </Link>.
              </Text>
            </div>
            <div className="col-12 col-md-4 text-right">
              {!isHome ? (
                <>
                  <Link href={'mailto:' + emailAddress}>
                    <a href="">
                      <Text color="white" fontSize="sm" inline>
                        <img
                          src="/icons/email_24px.svg"
                          width="16"
                          alt="email"
                          className="mr-2"
                        />
                        {emailAddress}
                      </Text>
                    </a>
                  </Link>
                  <Spacer direction="horizontal" size={25} />
                  <Link href={'tel:' + contactNumber}>
                    <a>
                      <Text color="white" fontSize="sm" inline>
                        <img
                          src="/icons/phone_24px.svg"
                          width="16"
                          alt="phone"
                          className="mr-2"
                        />
                        {contactNumber}
                      </Text>
                    </a>
                  </Link>
                </>
              ) : null}
            </div>
          </div>
        </div>
      </StyledFooter>
      <WhatsappFooterButton device={device} />
    </>
  );
};

export default Footer;
