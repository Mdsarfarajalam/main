
import styled from "styled-components";

export const QuoteContainer = styled.div`
max-width: 264px;
margin: auto;
`;