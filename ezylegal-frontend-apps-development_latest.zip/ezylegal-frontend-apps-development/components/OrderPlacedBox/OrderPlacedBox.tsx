import { FC } from 'react';

import Text from '../../styled/Text';
import Spacer from '../../styled/Spacer';
import CrossedText from '../../styled/CrossedText';
import savePercentage from '../../utils/savePercentage';
import { OrderSummaryWrapper, StyledDivider } from './OrderPlacedBox.styled';
import { useSelector } from 'react-redux';
import { RootState } from '../../redux/store';

interface TotalSaving {
  totalSaving: number | null;
  totalSavingPer: number | null;
}

interface OrderPlacedBoxProps {
  items: Array<any>;
  totalSaving: TotalSaving;
  subTotal: number | null;
  taxTotal: number | null;
  totalPrice: number | null;
}

const OrderPlacedBox: FC<OrderPlacedBoxProps> = ({
  items,
  totalSaving,
  subTotal,
  taxTotal,
  totalPrice,
}) => {
  const orderData = useSelector((store: RootState) => store.currentOrders);
  return (
    <>
      <OrderSummaryWrapper>
        <div className="d-flex flex-column justify-content-center align-items-center mb-5">
          <img
            src="https://i.ibb.co/SVZBVvQ/image-26tick.png"
            alt="image-26tick"
          />
          <div className="d-flex flex-row justify-content-center align-items-center w-100 mt-3">
            <Text fontSize={'md'} weight={'bold'}>
              Your Order Id is
            </Text>
            <Spacer size={10} direction={'horizontal'} />
            <Text fontSize={'md'} color={'gray'}>
              {orderData.data.createOrder._id}
            </Text>
          </div>
          <hr
            style={{
              width: '100%',
            }}
          />
        </div>
        <Text fontSize="lg">Product Summary</Text>
        <Spacer direction="vertical" size={20} />
        {items.map((item: any) => {
          return (
            <div key={item.id} className="row">
              <div className="col">
                <Text color="secondary">{item.name}</Text>
              </div>
              <div className="col text-right">
                <Text color="secondary">&#8377; {item.salePrice}</Text>
                {item.regularPrice && (
                  <>
                    <Spacer direction="vertical" size={5} />
                    <CrossedText fontSize="xs" inline>
                      &#8377; {item.regularPrice} /-
                    </CrossedText>
                    <Spacer direction="horizontal" size={8} />
                    <Text color="gray" fontSize="xs" inline>
                      (
                      {savePercentage(
                        Number(item.regularPrice),
                        Number(item.salePrice)
                      )}
                      % off)
                    </Text>
                  </>
                )}
              </div>
            </div>
          );
        })}
        <Spacer direction="vertical" size={25} />
        {subTotal ? (
          <div className="row">
            <div className="col">
              <Text color="secondary2">Sub Total</Text>
            </div>
            <div className="col text-right">
              <Text color="secondary2">&#8377; {subTotal}</Text>
            </div>
          </div>
        ) : null}
        {taxTotal ? (
          <div className="row">
            <div className="col">
              <Text color="secondary2">Tax Total</Text>
            </div>
            <div className="col text-right">
              <Text color="secondary2">&#8377; {taxTotal}</Text>
            </div>
          </div>
        ) : null}
        {totalSaving.totalSaving ? (
          <div className="row">
            <div className="col">
              <Text color="secondary2">Total Saving</Text>
            </div>
            <div className="col text-right">
              <Text color="secondary2">
                &#8377;{totalSaving.totalSaving}/- ({totalSaving.totalSavingPer}
                % off)
              </Text>
            </div>
          </div>
        ) : null}
        <StyledDivider margin="15px" />
        {totalPrice ? (
          <div className="row">
            <div className="col">
              <Text>Total Price</Text>
            </div>
            <div className="col text-right">
              <Text fontSize="xl" color="brown" weight="bold">
                &#8377;{totalPrice}/-
              </Text>
            </div>
          </div>
        ) : null}
        <div
          className="d-flex justify-content-end"
          style={{
            marginRight: '-30px',
          }}
        >
          <img
            src="https://i.ibb.co/YhKs6F9/image-27paid.png"
            alt="image-27paid"
          />
        </div>
      </OrderSummaryWrapper>
      <Spacer direction="vertical" size={22} />
      <div className="text-center">
        <Text fontSize="sm" weight="bold">
          PAYMENTS ARE SECURED WITH
        </Text>
        <Spacer direction="vertical" size={15} />
        <div className="d-flex align-items-center justify-content-center">
          <img src="/images/g-pay.png" alt="GPay" height="35" />
          <Spacer direction="horizontal" size={15} />
          <img src="/images/verified-visa.png" alt="Visa" height="35" />
          <Spacer direction="horizontal" size={15} />
          <img src="/images/mastercard.png" alt="Mastercard" height="35" />
          <Spacer direction="horizontal" size={15} />
          <img src="/images/paytm.png" alt="Paytm" height="35" />
        </div>
      </div>
    </>
  );
};

export default OrderPlacedBox;
