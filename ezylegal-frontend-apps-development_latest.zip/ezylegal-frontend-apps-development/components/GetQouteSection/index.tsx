import { useState } from 'react';
import { FC } from 'react';
import Button from '../../styled/Button';
import Text from '../../styled/Text';
import CorneredBox from '../CorneredBox';
import TellUsPopup from '../TellUsPopup';

// interface GetQouteSectionProps {
//   bgColorBack?: 'primary' | 'secondary' | 'darkBlue' | 'skyBlue' | 'white' | 'lightSkyBlue';
// }

const GetQouteSection: FC<any> = ({ bgColorBack }) => {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <CorneredBox
      bgColor="secondary"
      bgColorBack={bgColorBack}
      paddingTop="35px"
      paddingBottom="35px"
    >
      <div className="container">
        <div className="row align-items-center">
          <div className="col-12 col-md-8">
            <div className="row align-items-center justify-content-center ">
              <img
                src={
                  'https://ezylegal-assets.s3.ap-south-1.amazonaws.com/quote_logo.svg'
                }
                width="120"
                className="col-6 col-md-2 mb-3 mb-md-0"
              />
              <Text
                color="white"
                weight="semibold"
                fontSize="lg"
                className="col-12 col-md-10 mb-3 mb-md-0"
              >
                Legal consultation from a provider attorney on business legal
                matters, with legal research for each issue if needed
              </Text>
            </div>
          </div>
          <div className="col-12 col-md-4 text-center">
            <Button
              rounded
              outline
              backgroundColor="white"
              size="lg"
              onClick={handleShow}
            >
              Get Legal Help
            </Button>
          </div>
        </div>
      </div>
      <TellUsPopup show={show} onHide={handleClose} size="lg" />
    </CorneredBox>
  );
};

export default GetQouteSection;
