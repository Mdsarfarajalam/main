import {FC, useEffect, useState} from 'react';

import LoginBox from './LoginBox';
import SignupBox from './SignupBox';
import { LoginModal, ModalBody } from './LoginPopup.styled';

interface LoginModalProps{
    show: boolean;
    handleClose: any;
    tabValue: string;
    setTab: any;
}

const LoginPopup: FC<LoginModalProps> = ({ show, handleClose, tabValue, setTab}) => {

    return (
        <LoginModal show={show} onHide={handleClose} centered size="xl">
            <ModalBody>
                { tabValue === "LOGIN" ? <LoginBox setTab={setTab}/> : <SignupBox setTab={setTab} handleClose={handleClose}/>}
            </ModalBody>
        </LoginModal>
    );
};

export default LoginPopup;