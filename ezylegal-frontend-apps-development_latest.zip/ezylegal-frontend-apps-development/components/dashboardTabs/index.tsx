import React, { FC, useState, useEffect } from 'react';
import { Subtabcontent } from '../../styled/StyledTabs';
import { Row, Col } from 'react-bootstrap';
import Text from '../../styled/Text';
import UploadModal from "../UploadModal";
import Button from '../../styled/Button';
import Link from 'next/link';
import StarRatingComponent from 'react-star-rating-component';
import ScheduleCall from '../ScheduleCall/ScheduleCall';
import DocumentDropdown from '../DocumentDropdown/DocumentDropdown';
import OrderReview from "../OrderReview/OrderReview";
import backendApi from "../../api/backendApi";
import {MarkAsCompleted} from "../../constants/queries/order";
import {errorToast, successToast} from "../../utils/toasts";
import {isEqual} from "lodash";

const comparator = (prevProps: any, nextProps: any) => {
  return isEqual(prevProps, nextProps);
}

const DashboardTabs: FC<any> = React.memo(({ data }) => {
  const [isOpen, setisOpen] = useState<Boolean>(false);

  const [uploadedDocuments, setUploadedDocuments] = useState([]);

  const [lawyerDeliverables, setLawyerDeliverables] = useState([]);

  const [showDropdown, setShowDropdown] = useState(false);

  const [showConfirmClosure, setShowConfirmClosure] = useState(false);

  useEffect(function (){
    console.log("Data has changed", data);
    if(data){
      const completedProducts = data?.products.filter((product: any) => product.status === "COMPLETED");
      if(completedProducts.length === data.products.length){
        setShowConfirmClosure(true);
      }
      console.log("Data is", data);
    }
  }, [data]);

  useEffect(
    function () {
      if (data) {
        const documentData = data.required_documents.map((doc: any) => {
          return {
            name: doc.document_name,
            url: doc.document_url,
            status: doc.document_status,
            id: doc._id,
          };
        });
        setUploadedDocuments(documentData);

        const lawyerUploadedDocs = data.products.map((product: any) => {
          return product.deliverables.map((deliverable: any) => {
            return {
              name: deliverable.deliverable_name,
              status: deliverable.deliverable_status,
              url: deliverable.deliverable_url,
              id: deliverable._id,
            };
          });
        });

        setLawyerDeliverables(lawyerUploadedDocs);
      }
    },
    [data]
  );

  const completedOrder = async () => {
    try{
      await backendApi.post('/', {
        query: MarkAsCompleted,
        variables: {
          order_id: data._id,
          status: "COMPLETED"
        }
      });
      successToast('Successfully marked as completed');
    }catch (e) {
      errorToast(e.message);
    }
  }


  const NotCompletedButtons = () => {
    return(
        <>
          <Link href="#">
            <a>
              <Button size="md" rounded className="arrow_btn mr-2">
                <img
                    src="/icons/mail_icon.svg"
                    alt="send message"
                    width="20"
                    className="mr-2"
                />
                Send Message
              </Button>
            </a>
          </Link>
          <Button
              size="md"
              onClick={() => setisOpen(true)}
              rounded
              className="arrow_btn"
          >
            <img
                src="/icons/call_icon.svg"
                alt="call"
                className="mr-2"
                width="20"
            />
            Call
          </Button>
          {isOpen ? <ScheduleCall setIsOpen={setisOpen} /> : <> </>}
        </>
    )
  }

  return (
    <>
      {data ? (
        <Subtabcontent>
          <Row>
            <Col md={6}>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                }}
              >
                <Text fontSize="md" color="black">
                  Order Id:
                </Text>
                <Text fontSize="md" className="ml-2" color="gray">
                  {data?._id}
                </Text>
              </div>
              <div className="othercont">
                <Text fontSize="sm" color="black">
                  Purchased on:
                  {new Date(data?.created_at).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                  , {data?.products.length} Product purchased
                </Text>

                <Text fontSize="xs" color="black">
                  Case Assigned to
                </Text>
                <Text fontSize="md" color="black">
                  {data?.assigned_user == null && 'Null'}
                </Text>
              </div>
            </Col>
            {data && (
              <Col md={6}>
                <div className="dottedbox">
                  <div className="row flex-row justify-content-end">
                    <div className="col-5 col-md-5">
                      <DocumentDropdown
                        fontSize={'md'}
                        text={`${uploadedDocuments.length} Documents added`}
                        dropdownItems={uploadedDocuments}
                        shift={true}
                      />
                    </div>

                    <div className="col-12 col-md-12">
                      <Button
                        size="md"
                        rounded
                        outline={true}
                        backgroundColor={'white'}
                        style={{
                          borderColor: '#396AE8',
                          color: '#396AE8',
                        }}
                        onClick={() => setShowDropdown(true)}
                        className="arrow_btn mr-2"
                      >
                        Upload Documents
                      </Button>
                      <UploadModal
                        orderId={data?._id}
                        show={showDropdown}
                        setShow={setShowDropdown}
                      />
                    </div>
                  </div>
                </div>
              </Col>
            )}
          </Row>
          {data && (
            <Row className="white_bg">
              <Col md={12}>
                <span key={`${data._id}-255}`}>
                  {data.products.map((el: any, index: number) => (
                    <div
                      className="compny_det"
                      style={{
                        minWidth: '300px',
                      }}
                      key={index * 2000}
                    >
                      <div className="row">
                        <div className="col-8">
                          <Text fontSize="sm" color="black" weight="bold">
                            {el.product_name}
                          </Text>
                        </div>

                        <div className="col-4">
                          <Text
                            fontSize="xxs"
                            style={{
                              background: el.status === "COMPLETED" ? 'green' : 'lightgray',
                              color: 'white',
                              textAlign: 'center',
                            }}
                          >
                            {el.status}
                          </Text>
                        </div>
                      </div>

                      {el.deliverables.length ? (
                        <Text fontSize="sm" color="primary">
                          {el.deliverables.length === 1
                            ? `${el.deliverables.length} document `
                            : `${el.deliverables.length} documents`}
                          uploaded by Lawyer
                        </Text>
                      ) : (
                        <></>
                      )}

                      <DocumentDropdown
                        dropdownItems={lawyerDeliverables[index]}
                        fontSize={'xs'}
                        text={'View Deliverables'}
                        shift={false}
                      />
                    </div>
                  ))}
                </span>
              </Col>
              <Col md={12}>
                {data.status !== "COMPLETED" ? showConfirmClosure ? <div className="row" key="completed-btn-container">
                  <div className="col-6 col-md-3">
                    <Button size={"md"} rounded={true} backgroundColor={"primary"} onClick={completedOrder} disabled={data === undefined}>
                      Confirm Closure
                    </Button>
                  </div>
                  <div className="col-12 col-md-6">
                    <OrderReview orderId={data._id}/>
                  </div>
                </div> : <NotCompletedButtons /> : null}
              </Col>
            </Row>
          )}
        </Subtabcontent>
      ) : (
        <></>
      )}
    </>
  );
}, comparator);

export default DashboardTabs;
