import React, {FC, useEffect, useState} from "react";
import Text from "../../styled/Text";
import CheckBox from "../CheckBox";

interface DropdownItem{
    name: string;
    url: string;
    status: string;
    id: string;

}


interface DocumentDropdownProps{
    dropdownItems: Array<DropdownItem>;
    fontSize: string;
    text: string;
    shift: boolean;
}

const DocumentDropdown: FC<DocumentDropdownProps> = ({dropdownItems, fontSize, text, shift}) => {

    const [checkedFiles, setCheckedFiles] = useState(Array<number>());
    const [show, setShow] = useState<boolean>(false);
    const downloadFile = (link: any) => {
        var element = document.createElement('a');
        element.setAttribute('download', '');
        element.setAttribute('target', '_blank');
        element.setAttribute('href', link);

        element.style.display = 'none';
        document.body.appendChild(element);

        element.click();

        document.body.removeChild(element);
    }

    const onCheckChange = (id: number, check: boolean) => {
        if(check){
            setCheckedFiles([...checkedFiles, id]);
        }else{
            setCheckedFiles(checkedFiles.filter(fileId => (fileId !== id)));
        }
    }

    const downloadSelectedFiles = () => {
        console.log("Here", checkedFiles);
        checkedFiles.forEach((fileId: number) => {
            downloadFile(dropdownItems[fileId].url);
        })
    }

    return(
        <>
            <Text
                fontSize={fontSize === "md" ? "md" : "xs"}
                color="primary"
                style={{
                    cursor: "pointer"
                }}
                onClick={() => {
                setShow(!show);
            }}>
                {text}
            </Text>
            <div className="dottedbox"
                 style={{
                     textAlign: 'left',
                     position: "absolute",
                     zIndex: 100,
                     backgroundColor: "white",
                     width: "250px",
                     display: show ? "block" : "none"
                 }}>
                <Text color="primary" onClick={downloadSelectedFiles} style={{
                    cursor: "pointer"
                }}>
                    <img
                        src="/icons/download_icon.svg"
                        alt="download-icon"/>
                    Download
                </Text>

                { dropdownItems?.map((docs: DropdownItem, i: number) => (
                    <>
                        <CheckBox key={docs.id} docId={i} name="Name Approvassssl Certificate" checkChanged={onCheckChange}>
                            <Text inline>
                                {docs.name}{"-"} <Text inline color="red">{`(${docs.status})`}</Text>
                            </Text>
                        </CheckBox>
                        <br />
                    </>
                ))}


            </div>
        </>

    );
}

export default DocumentDropdown;