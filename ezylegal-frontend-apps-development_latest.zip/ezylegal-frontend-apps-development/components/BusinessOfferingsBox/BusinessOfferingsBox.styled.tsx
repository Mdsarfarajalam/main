import styled from "styled-components";

export const BusinessOfferingsWrapper = styled.section`
    padding: 70px 0;
`;