import { FC, useMemo, useState, useEffect } from 'react';
import { Accordion, Card } from 'react-bootstrap';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useRouter } from 'next/router';
import { useDispatch, useSelector } from 'react-redux';
import { sumBy } from 'lodash';
import getConfig from 'next/config';
import axios from 'axios';

import { RootState } from '../../redux/store';
import { getTaxes } from '../../redux/tax/tax.actions';
import savePercentage from '../../utils/savePercentage';
import Text from '../../styled/Text';
import Spacer from '../../styled/Spacer';
import Button from '../../styled/Button';
import RazorpayCheckout from '../RazorpayCheckout';
import RadioBox from '../RadioBox/index';
import PaymentSummaryBox from '../PaymentSummaryBox';
import {
  CheckoutWrapper,
  CardHeader,
  CheckoutCard,
} from './CheckoutBox.styled';
import {
  checkout,
  createNewOrder,
  updateAndCheckout,
} from '../../redux/currentOrder/currentOrder.actions';
import CheckoutForm from '../CheckoutForm/CheckoutForm';
import { errorToast, infoToast } from '../../utils/toasts';

export interface CheckoutFormData {
  name: string;
  email: string;
  countryCode: string;
  mobile: string;
  type: string;
}

const besicDetailSchema = yup.object().shape({
  name: yup.string().required(),
  email: yup.string().email().required(),
  countryCode: yup.string().required(),
  type: yup.string().required(),
  mobile: yup.string().matches(new RegExp('[0-9]{10}')).required(),
});

const CheckoutBox: FC = () => {
  const { publicRuntimeConfig } = getConfig();
  const { APP_NAME, RAZORPAY_KEY_ID } = publicRuntimeConfig;

  const [activeKey, setActiveKey] = useState<string>('0');
  const [formData, setFormData] = useState<CheckoutFormData | null>(null);
  const router = useRouter();
  const dispatch = useDispatch();
  const cart = useSelector((store: RootState) => store.cart);
  const loggedInUser = useSelector((store: RootState) => store.loggedInUser);
  const tax = useSelector((store: RootState) => store.tax);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [isUpdateRequested, setIsUpdateRequested] = useState<boolean>(false);

  useEffect(
    function () {
      if (cart.items.length === 0) {
        infoToast('Cart is empty. Please add items to proceed.');
        router.push('/');
      }
    },
    [cart]
  );

  useEffect(
    function () {
      if (loggedInUser && loggedInUser._id) {
        setIsLoggedIn(true);
        setFormData({
          name: loggedInUser.name,
          email: loggedInUser.email,
          countryCode: loggedInUser.country_code.toString(),
          type: loggedInUser.user_type,
          mobile: loggedInUser.mobile.toString(),
        });
      }
    },
    [loggedInUser]
  );

  useEffect(
    function () {
      if (isUpdateRequested) {
        setActiveKey('0');
      }
    },
    [isUpdateRequested]
  );

  useEffect(
    function () {
      if (formData !== null && cart.items.length > 0) {
        dispatch(
          createNewOrder(loggedInUser, cart, tax, () => {
            setActiveKey('1');
          })
        );
      }
    },
    [formData]
  );

  useEffect(() => {
    dispatch(getTaxes(router.locale || 'in'));
  }, []);

  const prices = useMemo(() => {
    const subTotal = sumBy(cart.items, (o) => Number(o.salePrice));
    const taxTotal = Math.ceil((subTotal / 100) * tax?.rate);

    return {
      totalRegularPrice: sumBy(cart.items, (o) => Number(o.regularPrice)),
      totalSalePrice: subTotal,
      totalPrice: subTotal + taxTotal,
      taxTotal: taxTotal,
    };
  }, [cart.items, tax]);

  const totalSaving = useMemo(() => {
    return {
      totalSaving: prices.totalRegularPrice - prices.totalSalePrice,
      totalSavingPer: savePercentage(
        prices.totalRegularPrice,
        prices.totalSalePrice
      ),
    };
  }, [prices]);

  const updateDetails = () => {
    setIsUpdateRequested(true);
  };

  const createOrder = async () => {
    const res = await axios.post('/api/orders');
    return res.data;
  };

  const checkoutHandler = async (response: any) => {
    const data = {
      // orderCreationId: order_id,
      razorpayPaymentId: response.razorpay_payment_id,
      razorpayOrderId: response.razorpay_order_id,
      razorpaySignature: response.razorpay_signature,
    };

    router.replace('/purchase-summary');
  };

  return (
    <CheckoutWrapper>
      <div className="container">
        <div className="row">
          <div className="col-12 col-md-8">
            <Accordion activeKey={activeKey}>
              <CheckoutCard>
                <CardHeader isSelected={activeKey === '0'}>
                  <Accordion.Toggle as="div" eventKey="0">
                    {activeKey === '0' ? (
                      <Text
                        fontFamily="montserrat"
                        fontSize="lg"
                        color="white"
                        weight="bold"
                      >
                        Fill your Contact Details
                      </Text>
                    ) : (
                      <div className="d-flex flex-column">
                        <Text
                          fontFamily="montserrat"
                          color="secondary"
                          weight="bold"
                        >
                          {formData?.name}
                        </Text>
                        <div className="d-flex justify-content-between">
                          <div className="d-flex align-items-center">
                            <img
                              src="/icons/email_black.svg"
                              alt="Email"
                              width="20"
                            />
                            <Spacer direction="horizontal" size={10} />
                            <Text color="secondary" inline>
                              {formData?.email}
                            </Text>
                            <Spacer direction="horizontal" size={10} />
                            <img
                              src="/icons/phone_black.svg"
                              alt="Phone"
                              width="20"
                            />
                            <Spacer direction="horizontal" size={10} />
                            <Text color="secondary" inline>
                              {formData?.mobile}
                            </Text>
                          </div>

                          <div className="d-flex align-items-center">
                            <img
                              src="https://i.ibb.co/XLZ9FPR/edit-24pxpencil.png"
                              alt="edit-24pxpencil"
                              height={20}
                            />
                            <a
                              style={{
                                color: '#396AE8',
                              }}
                              onClick={updateDetails}
                            >
                              Edit Details
                            </a>
                          </div>
                        </div>
                      </div>
                    )}
                  </Accordion.Toggle>
                </CardHeader>
                <Accordion.Collapse eventKey="0">
                  <Card.Body>
                    {activeKey === '0' ? (
                      <CheckoutForm
                        formData={formData}
                        isUpdateRequested={isUpdateRequested}
                        setFormData={setFormData}
                        setActiveKey={setActiveKey}
                        loggedInUser={loggedInUser}
                        cart={cart}
                        tax={tax}
                        setIsUpdateRequested={setIsUpdateRequested}
                      />
                    ) : (
                      <></>
                    )}
                  </Card.Body>
                </Accordion.Collapse>
              </CheckoutCard>
              <Spacer direction="vertical" size={20} />
              <CheckoutCard>
                <CardHeader isSelected={activeKey === '1'}>
                  <Accordion.Toggle as="div" eventKey="1">
                    <Text
                      fontFamily="montserrat"
                      fontSize="lg"
                      color={activeKey === '1' ? 'white' : 'secondary'}
                      weight="bold"
                    >
                      Payment Options
                    </Text>
                  </Accordion.Toggle>
                </CardHeader>
                // TODO Need to bring in product which is selected for payment
                {/* {product.product_addition?.productCharacteristics?.map(
                  (productCharacteristic: ProductCharacteristics) => {
                    return (
                      <div className="d-flex">
                        <img
                          src={productCharacteristic.icon?.sourceUrl}
                          alt={productCharacteristic.icon?.title}
                          width={35}
                          className="mr-2"
                        />

                        <Text inline color="secondary2" className="mb-0">
                          {productCharacteristic.label}
                        </Text>
                      </div>
                    );
                  }
                )} */}
                <Accordion.Collapse eventKey="1">
                  <Card.Body>
                    <RazorpayCheckout
                      razorpay_key={RAZORPAY_KEY_ID}
                      createOrder={createOrder}
                      handler={checkoutHandler}
                      name={APP_NAME}
                      description="Payment for your order"
                      image={'/images/logo.svg'}
                      prefill={{
                        name: formData?.name,
                        contact: formData?.countryCode + ' ' + formData?.mobile,
                        email: formData?.email,
                      }}
                      theme={{ color: '#396AE8' }}
                    />
                  </Card.Body>
                </Accordion.Collapse>
              </CheckoutCard>
            </Accordion>
          </div>
          <div className="col-12 col-md-4">
            <PaymentSummaryBox
              items={cart.items}
              subTotal={prices.totalSalePrice}
              taxTotal={prices.taxTotal}
              totalSaving={totalSaving}
              totalPrice={prices.totalPrice}
            />
          </div>
        </div>
      </div>
    </CheckoutWrapper>
  );
};

export default CheckoutBox;
