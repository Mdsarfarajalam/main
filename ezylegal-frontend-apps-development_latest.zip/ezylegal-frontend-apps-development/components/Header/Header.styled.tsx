import { Card, Navbar, NavDropdown, Dropdown } from 'react-bootstrap';
import styled, { css } from 'styled-components';

import Text from '../../styled/Text';

export const DropdownTogle = styled(Dropdown.Toggle)`
  background: #fff;
  color: black;
  border: 2px solid lightgray;
  border-radius: 25px;
  padding: 10px 25px;
  &.active {
    background-color: #f1f9fe;
    border-top: 2px solid #0078db;
    border-bottom: 2px solid transparent;
    border: none;
  }
`;

export const NavLink = styled(Text)`
  padding: 1rem 1rem;
  color: ${({ theme }) => theme.textColors['black']};
  margin-bottom: 0px !important;
  min-height: 80px;
  line-height: 50px;

  &.active {
    background-color: #f1f9fe;
    border-top: 2px solid #0078db;
    border-bottom: 2px solid transparent;
  }
`;

export const StyledNavDropdown = styled(NavDropdown)`
  position: static;

  & .nav-link {
    padding: 1rem 1rem !important;
    height: 80px;
    line-height: 50px;
  }

  & > .dropdown-menu {
    width: 100%;
    padding: 0;
    border-radius: 0;
    border: 0;
    box-shadow: 0 8px 9px -6px rgb(0 0 0 / 40%);
    top: calc(100% + 1px);
  }
`;

export const StyledNavbar = styled(Navbar)`
  background-color: transparent !important;
  padding: 0 1rem;
  & .navbar-brand {
    padding-top: 1rem;
    padding-bottom: 1rem;
  }
`;

export const CardBox = styled(Card)`
  border-radius: 0 !important;
  border: 0;
`;

interface CardHeaderProps {
  border: boolean;
}

export const CardHeader = styled(Card.Header)<CardHeaderProps>`
  background-color: transparent;
  border-radius: 0 !important;
  border: 0;
  padding: 10px 20px;

  ${(props) =>
    props.border &&
    css`
      border-bottom: 1px solid #dad8d8;
    `}
`;

export const CardBody = styled(Card.Body)`
  background-color: transparent;
  padding: 0 0 0 20px;
`;

export const LinkText = styled(Text)`
  padding: 10px 20px;
  margin: 0;
`;

export const MenuButton = styled.button`
  background-color: transparent;
  border: 0;
`;

export const SignInDropdown = styled.ul`
  margin: 0;
  background-color: #ffffff;
  color: #09b2e8;
  border: 2px solid #e5e5e5;
  padding: 0 0 0 1em;
  position: absolute;
  z-index: 100;
  width: 200px;

  &.hide {
    display: none;
  }
`;

export const SignInDropdownElement = styled.li`
  list-style: none;
  margin-bottom: 0.8em;
  cursor: pointer;
  &.colors {
    color: #396ae8;
    font-weight: bold;
  }
`;
