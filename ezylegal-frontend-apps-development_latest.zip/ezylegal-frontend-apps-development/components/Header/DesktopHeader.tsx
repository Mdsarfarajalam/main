import { FC, useState, useRef, useEffect } from 'react';
import { Nav, Navbar } from 'react-bootstrap';
import Link from 'next/link';

import MenuItem from '../../dtos/MenuItem.dto';
import Button from '../../styled/Button';
import Spacer from '../../styled/Spacer';
import Text from '../../styled/Text';
import CorneredBox from '../CorneredBox';
import SlideSearchBox from '../SlideSearchBox';
import ActiveLink from '../ActiveLink';
import LoginPopup from '../LoginPopup';
import {
  NavLink,
  StyledNavDropdown,
  StyledNavbar,
  SignInDropdown,
  SignInDropdownElement,
  DropdownTogle,
} from './Header.styled';
import DropDownContainer from './DropDownContainer';
import Dropdown from 'react-bootstrap/Dropdown';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../../redux/store';
import { setLoggedInUser } from '../../redux/loggedInUser/loggedInUser.actions';

interface HeaderProps {
  headerMenu?: MenuItem[];
  bgColorBack?:
    | 'primary'
    | 'secondary'
    | 'darkBlue'
    | 'skyBlue'
    | 'white'
    | 'lightSkyBlue';
}

interface LoginModalControls {
  show: boolean;
  tabValue: string;
}

const DesktopHeader: FC<HeaderProps> = ({ headerMenu, bgColorBack }) => {
  const [isOpen, setIsOpen] = useState<LoginModalControls>({
    show: false,
    tabValue: 'LOGIN',
  });
  const [showDropdown, setShowDropdown] = useState<boolean>(false);
  const [hoverId, setHoverId] = useState<string>('');
  const dispatch = useDispatch();
  const loggedInUserData = useSelector(
    (store: RootState) => store.loggedInUser
  );
  const [showSignInDropdown, setShowSignInDropdown] = useState<boolean>(false);
  const handleClose = () => {
    setIsOpen({
      ...isOpen,
      show: false,
    });
  };
  const Signout_User = () => {
    dispatch(setLoggedInUser(null));
  };

  const outsideClickListener = (ref: any) => {
    useEffect(() => {
      function handleOutsideClick(event: MouseEvent) {
        if (ref.current && !ref.current.contains(event.target)) {
          setShowSignInDropdown(false);
        }
      }

      document.addEventListener('mousedown', handleOutsideClick);

      return () => {
        document.removeEventListener('mousedown', handleOutsideClick);
      };
    }, [ref]);
  };

  const wrapperRef = useRef(null);
  outsideClickListener(wrapperRef);

  const setTab = (value: string) => {
    setIsOpen({
      ...isOpen,
      tabValue: value,
    });
  };

  return (
    <CorneredBox bgColor="white" bgColorBack={bgColorBack}>
      <StyledNavbar expand="lg">
        <div className="container d-flex">
          <Link href="/">
            <a>
              <Navbar.Brand>
                <img
                  src="/images/logo.svg"
                  alt="Logo"
                  height="47"
                  className="d-inline-block align-text-top"
                />
              </Navbar.Brand>
            </a>
          </Link>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            {/* this is list item */}
            <Nav className="m-auto">
              {headerMenu?.map((menu: MenuItem) =>
                menu.children.length ? (
                  <StyledNavDropdown
                    key={menu.id}
                    title={
                      <Text inline weight="bold">
                        {menu.label}
                      </Text>
                    }
                    id={menu.id}
                    show={menu.id == hoverId && showDropdown && true}
                    onMouseEnter={() => {
                      setShowDropdown(true);
                      setHoverId(menu.id);
                    }}
                    onMouseLeave={() => {
                      setShowDropdown(false);
                      setHoverId('');
                    }}
                  >
                    <DropDownContainer menu={menu} />
                  </StyledNavDropdown>
                ) : (
                  <ActiveLink key={menu.id} href={menu.url}>
                    <a>
                      <NavLink fontSize="base" weight="bold">
                        {menu.label}
                      </NavLink>
                    </a>
                  </ActiveLink>
                )
              )}
            </Nav>
            <div style={{ display: 'flex', width: '25%' }}>
              <SlideSearchBox />
              <Spacer direction="horizontal" size={10} />
              {!loggedInUserData?.name ? (
                <div
                  style={{
                    position: 'relative',
                  }}
                >
                  <Button
                    size="md"
                    rounded
                    style={{
                      width: "150px"
                    }}
                    onClick={() => setShowSignInDropdown(true)}
                  >
                    Sign In
                  </Button>
                  <SignInDropdown
                    ref={wrapperRef}
                    className={showSignInDropdown ? 'show py-3' : 'hide py-3'}
                  >
                    <Text fontSize="md" color="gray-500" weight="bold">
                      For Customers
                    </Text>
                    <SignInDropdownElement
                      className="colors"
                      onClick={() => {
                        setIsOpen({
                          show: true,
                          tabValue: 'LOGIN',
                        });
                        setShowSignInDropdown(false);
                      }}
                    >
                      Login
                    </SignInDropdownElement>
                    <SignInDropdownElement
                      className="colors"
                      onClick={() => {
                        setIsOpen({
                          show: true,
                          tabValue: 'REGISTER',
                        });
                        setShowSignInDropdown(false);
                      }}
                    >
                      Register
                    </SignInDropdownElement>
                    <Spacer direction="horizontal" size={10} />
                    <Text fontSize="md" color="gray-500" weight="bold">
                      For Lawyers & CA
                    </Text>
                    <SignInDropdownElement className="colors">
                      Login
                    </SignInDropdownElement>
                    <SignInDropdownElement className="colors">
                      Register
                    </SignInDropdownElement>
                  </SignInDropdown>
                </div>
              ) : (
                <Dropdown>
                  <DropdownTogle id="dropdown-basic">
                    {loggedInUserData?.name}
                  </DropdownTogle>

                  <Dropdown.Menu>
                    <Dropdown.Item>My Profile</Dropdown.Item>
                    <Dropdown.Item onClick={() => Signout_User()}>
                      Sign out
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              )}
            </div>
          </Navbar.Collapse>
        </div>
      </StyledNavbar>
      {/* This is Login popup page  */}
      {isOpen && (
        <LoginPopup
          tabValue={isOpen.tabValue}
          show={isOpen.show}
          handleClose={handleClose}
          setTab={setTab}
        />
      )}
    </CorneredBox>
  );
};

export default DesktopHeader;
