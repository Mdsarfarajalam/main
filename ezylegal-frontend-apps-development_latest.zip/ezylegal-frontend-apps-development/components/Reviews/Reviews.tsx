import { FC, useState } from 'react';
import Review from '../../dtos/Review.dto';
import Text from '../../styled/Text';
import Spacer from '../../styled/Spacer';
import StarRating from '../StarRating';
import Divider from '../../styled/Divider';
import StillHaveQuestion from '../StillHaveQuestions/StillHaveQuestions';
import Button from '../../styled/Button';
import { RatingModal } from '../RatingAndReview/RatingAndReview';

interface DataType {
  averageRating: number;
  reviews: Review[];
}

interface ReviewsProps {
  data: DataType;
}

const Reviews: FC<ReviewsProps> = ({ data }) => {
  const [showRatingModal, setShowRatingModal] = useState<boolean>(false);

  return (
    <div className="container">
      <RatingModal show={showRatingModal} setShow={setShowRatingModal} />
      <div className="row">
        <div className="col-8 col-md-8">
          <Text fontFamily="montserrat" fontSize="xxxl" weight="bold">
            Reviews
          </Text>
          <Spacer direction="vertical" size={5} />
          <div className="d-flex align-items-center">
            <StarRating readonly initialRating={data.averageRating} />
            <Spacer direction="horizontal" size={8} />
            <Text inline fontSize="sm" color="gray" className="mb-0">
              {data.reviews.length} reviews
            </Text>
          </div>
        </div>

        <div className="col-4 col-md-4 d-flex justify-content-center align-items-center">
          <Button
            size={'md'}
            backgroundColor={'primary'}
            rounded={true}
            onClick={() => {
              setShowRatingModal(true);
            }}
          >
            Write a Review
          </Button>
        </div>
      </div>

      <Spacer direction="vertical" size={10} />
      <Divider color="black" margin="20px" />
      <ul className="list-unstyled">
        {data.reviews.map((review: Review, index: number) => {
          return (
            <li className="mb-4" key={index}>
              <div className="d-flex">
                <Text weight="bold" fontSize="md">
                  {review.author.name}
                </Text>
                <Spacer direction="horizontal" size={8} />
              </div>
              <Text
                fontSize="sm"
                as="div"
                dangerouslySetInnerHTML={{ __html: review.content || '' }}
                color="gray"
              ></Text>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default Reviews;
