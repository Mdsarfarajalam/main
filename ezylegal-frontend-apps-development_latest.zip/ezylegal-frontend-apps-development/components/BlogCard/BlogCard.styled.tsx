import styled from "styled-components";

export const BlogCardWrapper = styled.div`
    padding: 10px;
    border: 1px solid #DBDDE6;
    margin-bottom: 30px;
    width: 100%;
`;