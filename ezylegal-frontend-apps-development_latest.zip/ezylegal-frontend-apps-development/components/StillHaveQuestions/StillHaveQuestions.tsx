import { FC, useLayoutEffect, useState } from 'react';
import StillHaveQuestions from '../../dtos/StillHaveQuestions.dto';
import Text from '../../styled/Text';
import Spacer from '../../styled/Spacer';
import Button from '../../styled/Button';
import { DeviceTypes } from '../../constants/deviceTypes';
import openWhatsapp from '../../utils/openWhatsapp';

interface StillHaveQuestionsProps {
  data?: StillHaveQuestions;
}

const StillHaveQuestion: FC<StillHaveQuestionsProps> = ({ data }) => {
  const [device, setDevice] = useState(DeviceTypes.DESKTOP);

  useLayoutEffect(() => {
    const handleResize = () => {
      setDevice(
        window.innerWidth < 768 ? DeviceTypes.MOBILE : DeviceTypes.DESKTOP
      );
    };

    handleResize();

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="container">
      <Text fontSize="xxxl" fontFamily="montserrat" weight="bold">
        {data?.heading}
      </Text>
      <div className="row">
        <div className="col-12 col-md-6  mb-2 mb-md-0 ">
          <div
            className="p-5"
            style={{
              border: '1px solid',
              borderColor: '#d0cece',
              borderRadius: '10px',
            }}
          >
            <div className="row">
              <div className="col col-md-7">
                <Text fontSize="xl" weight="bold">
                  {data?.leftBox.heading}
                </Text>
                <Text fontSize="lg" weight="semibold">
                  {data?.leftBox.content}
                </Text>
              </div>
              <div className="col col-md- d-flex justify-content-center align-items-center">
                <img
                  src={data?.leftBox.image?.sourceUrl}
                  alt={data?.leftBox.image?.title}
                  width={80}
                />
              </div>
            </div>
            <div className="mt-3">
              <Button
                size={'md'}
                as={'a'}
                backgroundColor={'darkBlue'}
                rounded={true}
                onClick={() => {
                  openWhatsapp(device);
                }}
              >
                {data?.leftBox.button.text}
              </Button>
            </div>
          </div>
        </div>
        <div className="col-12 col-md-6 ">
          <div
            className="p-5 h-100"
            style={{
              border: '1px solid',
              borderColor: '#d0cece',
              borderRadius: '10px',
            }}
          >
            <Text fontSize="xl" weight={'bold'}>
              {data?.rightBox.heading}
            </Text>
            <div className="row mt-5">
              <div className="col-12">
                {data?.rightBox.timing.map((timing: any, index: number) => {
                  return (
                    <Text
                      fontSize="xl"
                      weight="semibold"
                      key={index}
                      className="mb-3"
                    >
                      {timing.availableSlot}
                    </Text>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StillHaveQuestion;
