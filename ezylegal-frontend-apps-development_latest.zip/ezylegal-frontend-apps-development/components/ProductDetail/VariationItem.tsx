import Link from 'next/link';
import { FC } from 'react';

import Variation from '../../dtos/Variation.dto';
import Button from '../../styled/Button';
import CrossedText from '../../styled/CrossedText';
import ShadowCard from '../../styled/ShadowCard';
import Spacer from '../../styled/Spacer';
import Text from '../../styled/Text';
import savePercentage from '../../utils/savePercentage';
import priceToInteger from '../../utils/priceToInteger';
import { useDispatch } from 'react-redux';
import { addItems } from '../../redux/cart/cart.actions';
import Category from "../../dtos/Category.dto";

interface VariationProps {
  variation: Variation;
  isLast: boolean;
  category: Category;
}

const VariationItem: FC<VariationProps> = ({ variation, isLast, category }) => {
  const dispatch = useDispatch();

  return (
    <div
      className="col-12 col-md-4 d-flex"
      style={{
        paddingRight: isLast ? '20px' : 'unset',
        paddingLeft: isLast ? '20px' : 'unset',
      }}
    >
      <ShadowCard backgroundColor={isLast ? 'skyBlue' : 'lightYellow'} bordered>
        <Text fontSize="md" weight="bold">
          {variation.name}
        </Text>
        <Spacer size={20} direction={'vertical'} />
        {variation.description?.map((item: string) => (
          <>
            {item.toLowerCase().includes('no') ? (
              <img width="20" src="/icons/remove_circle_24px.svg" alt="icon" />
            ) : (
              <img width="20" src="/icons/check_circle_24px.svg" alt="icon" />
            )}
            <Spacer direction="horizontal" size={8} />
            <Text fontSize="sm" inline>
              {item}
            </Text>
            <Spacer direction="vertical" size={5} />
          </>
        ))}
        <Text color="brown" fontSize="xl" inline>
          &#8377; {variation.salePrice}
        </Text>
        {variation.regularPrice && (
          <>
            <Spacer direction="horizontal" size={8} />
            <CrossedText inline>&#8377; {variation.regularPrice} /-</CrossedText>
            <Spacer direction="horizontal" size={8} />
            <Text inline>
              {savePercentage(
                priceToInteger(variation.regularPrice),
                priceToInteger(variation.salePrice)
              )}
              % off
            </Text>
          </>
        )}
        <Spacer direction="vertical" size={10} />
        <Link href="/checkout">
          <a>
            <Button
              size="md"
              rounded
              onClick={() => {
                const variationData = {
                  ...variation,
                  category: category,
                  price: priceToInteger(variation.price),
                  regularPrice: priceToInteger(variation.regularPrice),
                  salePrice: priceToInteger(variation.salePrice),
                };
                dispatch(addItems([variationData]));
              }}
            >
              Buy Service
              <img src="/icons/arrow-forward.svg" alt="Forward" width="18" />
            </Button>
          </a>
        </Link>
      </ShadowCard>
    </div>
  );
};

export default VariationItem;
