import { sumBy } from 'lodash';
import { FC, useEffect, useMemo, useState } from 'react';
import { useDispatch } from 'react-redux';

import Product from '../../../dtos/Product.dto';
import Upsell from '../../../dtos/Upsell.dto';
import { addItems } from '../../../redux/cart/cart.actions';
import Button from '../../../styled/Button';
import CrossedText from '../../../styled/CrossedText';
import Divider from '../../../styled/Divider';
import Spacer from '../../../styled/Spacer';
import Text from '../../../styled/Text';
import savePercentage from '../../../utils/savePercentage';
import CheckBox from '../../CheckBox';
import AddonItem from './AddonItem';
import { AddonBoxWrapper } from './SimpleProduct.styled';
import priceToInteger from '../../../utils/priceToInteger';

interface AddonBoxProps {
  product: Product;
}

// TODO Update Total Price whenever any additional option is selected
const AddonBox: FC<AddonBoxProps> = ({ product }) => {
  const [selected, setSelected] = useState<Array<Upsell>>([]);
  const dispatch = useDispatch();

  useEffect(() => {
    setSelected([product as Upsell]);
  }, []);

  const prices = useMemo(() => {
    return {
      totalRegularPrice: sumBy(selected, (o) => Number(o.regularPrice)),
      totalSalePrice: sumBy(selected, (o) => Number(o.salePrice)),
    };
  }, [selected]);

  const totalSaving = useMemo(() => {
    return {
      totalSaving: prices.totalRegularPrice - prices.totalSalePrice,
      totalSavingPer: savePercentage(
        prices.totalRegularPrice,
        prices.totalSalePrice
      ),
    };
  }, [prices]);

  const onBuyClick = () => {
    const selectedItems: Array<any> = selected.map((item: Upsell) => {
      return {
        ...item,
        otherRegularPrice: priceToInteger(item.otherRegularPrice),
        otherSalePrice: priceToInteger(item.otherSalePrice),
        regularPrice: priceToInteger(item.regularPrice),
        salePrice: priceToInteger(item.salePrice),
      };
    });

    dispatch(addItems(selectedItems));
  };

  return (
    <AddonBoxWrapper>
      <div className="d-flex flex-wrap">
        <CheckBox
          name={product.name}
          checked
          readOnly
          checkChanged={() => {}}
          docId={0}
          className="w-full"
        >
          <Text inline weight="bold">
            {product.name}
          </Text>
          <Spacer direction="horizontal" size={12} />
          <Text
            fontSize="sm"
            inline
            weight="bold"
            color="korma"
            className="ml-auto"
          >
            ₹ {product.salePrice} /-
          </Text>
        </CheckBox>
        {product.regularPrice && (
          <div className="ml-auto">
            <Spacer direction="horizontal" size={12} />
            <CrossedText fontSize="sm" inline>
              ₹ {product.regularPrice} /-
            </CrossedText>
            <Spacer direction="horizontal" size={12} />
            <Text fontSize="sm" inline>
              {savePercentage(
                priceToInteger(product.regularPrice),
                priceToInteger(product.salePrice)
              )}
              % off
            </Text>
          </div>
        )}
      </div>
      {product.upsell?.length ? (
        <div>
          <Divider margin="15px" color="black" />
          <Text fontSize="sm" weight="bold">
            Additional services at attractive discount
          </Text>
          <Spacer direction="vertical" size={15} />
          {product.upsell?.map((addon) => (
            <AddonItem
              key={addon.id}
              addon={addon}
              selected={selected}
              setSelected={setSelected}
            />
          ))}
        </div>
      ) : null}

      <Spacer direction="vertical" size={20} />
      <div className="d-flex justify-content-between">
        <Text weight="bold" inline>
          Total Price
        </Text>
        <Spacer direction="horizontal" size={12} />
        <Text weight="bold" color="korma" fontSize="xl" inline>
          &#8377;
          {isNaN(prices.totalSalePrice)
            ? priceToInteger(product.salePrice)
            : prices.totalSalePrice}
          /-
        </Text>
      </div>
      {totalSaving.totalSaving && (
        <>
          <hr />
          <div className="d-flex justify-content-between">
            <Text color="gray" inline>
              Total Saving
            </Text>
            <Spacer direction="horizontal" size={12} />

            <Text color="gray" inline>
              &#8377;{totalSaving.totalSaving}/- ({totalSaving.totalSavingPer}%
              off)
            </Text>
          </div>
        </>
      )}
      <Spacer direction="vertical" size={20} />
      <Button size="md" rounded onClick={onBuyClick}>
        Buy Service
        <img src="/icons/arrow-forward.svg" alt="Forward" width="18" />
      </Button>
    </AddonBoxWrapper>
  );
};

export default AddonBox;
