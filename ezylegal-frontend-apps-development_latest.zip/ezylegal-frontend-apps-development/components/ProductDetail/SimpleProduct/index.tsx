import { FC, useState } from 'react';

import Product from '../../../dtos/Product.dto';
import Spacer from '../../../styled/Spacer';
import Text from '../../../styled/Text';
import AddonBox from './AddonBox';
import ProductFeature from '../../../dtos/ProductFeature.dto';
import ProductCharacteristics from '../../../dtos/ProductCharacteristics.dto';
import SocialLinksShare from "../../SocialLinksShare/SocialLinksShare";

interface SimpleProductProps {
  product: Product;
}

const SimpleProduct: FC<SimpleProductProps> = ({ product }) => {
  return (
    <div className="row">
        <SocialLinksShare />
      <div className="col-12 col-md-7">
        <Text fontSize="xxxl" fontFamily="montserrat" weight="bold">
          {product.name}
        </Text>
        <Spacer direction="vertical" size={10} />
        <div className="d-flex align-items-center justify-content-lg-start">
          <img
            src={
              'https://ezylegal-assets.s3.ap-south-1.amazonaws.com/file_copy_24pxicon1.png'
            }
            alt={'copy'}
            width={20}
            className="mr-2"
          />
          <Text
            fontSize="md"
            weight="bold"
            style={{
              margin: 'unset',
            }}
          >
            {product.category.slug === 'documentation'
              ? '5000+ Documents delivered'
              : '900 + Registrations Delivered'}
          </Text>
          <Spacer size={20} direction={'horizontal'} />
          <img
            src={
              'https://ezylegal-assets.s3.ap-south-1.amazonaws.com/stars_24pxicon2.png'
            }
            alt={'stars'}
            width={20}
            className="mr-2"
          />
          <Text
            fontSize="md"
            weight="bold"
            style={{
              margin: 'unset',
            }}
          >
            {product.category.slug === 'documentation'
              ? 'Trusted By 1000+ Businesses'
              : 'Trusted By 500+ Businesses'}
          </Text>
        </div>

        <Spacer size={10} direction={'vertical'} />
        <Spacer direction="vertical" size={14} />
        <Text
          fontSize="lg"
          as="div"
          dangerouslySetInnerHTML={{ __html: product.description || '' }}
          weight="normal"
        ></Text>
        <Spacer direction="vertical" size={10} />
        {product.product_addition?.productFeature?.map(
          (productFeature: ProductFeature, index: number) => {
            return (
              <div className="mb-1" key={index}>
                <img
                  width={24}
                  src={productFeature.icon?.sourceUrl}
                  alt={productFeature.icon?.title}
                  className="mr-2"
                />
                <Text inline fontSize="md" weight="semibold" color="secondary2">
                  {productFeature.description}
                </Text>
              </div>
            );
          }
        )}

        <Spacer direction="vertical" size={10} />

        <hr
          style={{
            marginTop: '1rem',
            marginBottom: '1rem',
            border: 0,
            borderTop: '1px solid rgba(0, 0, 0, 0.1)',
          }}
        />

        <div
          style={{
            display: 'flex',
            justifyContent: 'space-around',
            gap: '1.5rem',
          }}
        >
          {product.product_addition?.productCharacteristics?.map(
            (productCharacteristic: ProductCharacteristics, index: number) => {
              return (
                <div className="d-flex" key={index}>
                  <img
                    src={productCharacteristic.icon?.sourceUrl}
                    alt={productCharacteristic.icon?.title}
                    width={35}
                    className="mr-2"
                  />

                  <Text
                    inline
                    color="secondary2"
                    className="mb-0"
                    fontSize="base"
                    weight="semibold"
                  >
                    {productCharacteristic.label}
                  </Text>
                </div>
              );
            }
          )}
        </div>
      </div>
      <div className="col-12 col-md-5 mt-5 mt-md-0">
        <AddonBox product={product} />
      </div>
    </div>
  );
};

export default SimpleProduct;
