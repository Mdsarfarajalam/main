import { FC } from 'react';

import Product from '../../dtos/Product.dto';
import Spacer from '../../styled/Spacer';
import Text from '../../styled/Text';
import StarRating from '../StarRating';
import VariationItem from './VariationItem';
import ProductFeature from '../../dtos/ProductFeature.dto';
import ProductCharacteristics from '../../dtos/ProductCharacteristics.dto';
import SocialLinksShare from "../SocialLinksShare/SocialLinksShare";

interface VariableProductProps {
  product: Product;
}

const VariableProduct: FC<VariableProductProps> = ({ product }) => {
  return (
    <>
        <SocialLinksShare />
      <div className="row">
        <div className="col-12 col-md-8">
          <Text fontSize="xxxl" fontFamily="montserrat" weight="bold">
            {product.name}
          </Text>
          <Spacer direction="vertical" size={10} />
          <div className="d-flex align-items-center justify-content-lg-start">
            <img
              src={
                'https://ezylegal-assets.s3.ap-south-1.amazonaws.com/file_copy_24pxicon1.png'
              }
              alt={'copy'}
              width={20}
              className="mr-2"
            />
            <Text
              fontSize="md"
              weight="bold"
              style={{
                margin: 'unset',
              }}
            >
              {product.category.slug === 'documentation'
                ? '5000+ Documents delivered'
                : '900 + Registrations Delivered'}
            </Text>
            <Spacer size={20} direction={'horizontal'} />
            <img
              src={
                'https://ezylegal-assets.s3.ap-south-1.amazonaws.com/stars_24pxicon2.png'
              }
              alt={'stars'}
              width={20}
              className="mr-2"
            />
            <Text
              fontSize="md"
              weight="bold"
              style={{
                margin: 'unset',
              }}
            >
              {product.category.slug === 'documentation'
                ? 'Trusted By 1000+ Businesses'
                : 'Trusted By 500+ Businesses'}
            </Text>
          </div>
          <Spacer direction="vertical" size={14} />
          <Text
            fontSize="lg"
            as="div"
            dangerouslySetInnerHTML={{ __html: product.description || '' }}
          ></Text>
        </div>
      </div>
      <Spacer direction="vertical" size={10} />
      {product.product_addition?.productFeature?.map(
        (productFeature: ProductFeature) => {
          return (
            <div className="mb-1">
              <img
                width={24}
                src={productFeature.icon?.sourceUrl}
                alt={productFeature.icon?.title}
                className="mr-2"
              />
              <Text inline fontSize="sm">
                {productFeature.description}
              </Text>
            </div>
          );
        }
      )}

      <Spacer direction="vertical" size={10} />

      <hr
        style={{
          marginTop: '1rem',
          marginBottom: '1rem',
          border: 0,
          borderTop: '1px solid rgba(0, 0, 0, 0.1)',
        }}
      />

      <div
        style={{
          display: 'flex',
          justifyContent: 'space-around',
        }}
        className="col col-md-6 mb-5"
      >
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-around',
            gap: '1.5rem',
          }}
        >
          {product.product_addition?.productCharacteristics?.map(
            (productCharacteristic: ProductCharacteristics) => {
              return (
                <div className="d-flex">
                  <img
                    src={productCharacteristic.icon?.sourceUrl}
                    alt={productCharacteristic.icon?.title}
                    width={35}
                    className="mr-2"
                  />

                  <Text inline color="secondary2" className="mb-0">
                    {productCharacteristic.label}
                  </Text>
                </div>
              );
            }
          )}
        </div>
      </div>

      <Spacer direction="vertical" size={15} />
      {product.variations?.length ? (
        <div className="row">
          {product.variations?.map((variation, i) => (
            <VariationItem
              key={variation.id}
              category={product.category}
              variation={variation}
              isLast={
                product.variations ? i === product.variations.length - 1 : true
              }
            />
          ))}
        </div>
      ) : null}
    </>
  );
};

export default VariableProduct;
