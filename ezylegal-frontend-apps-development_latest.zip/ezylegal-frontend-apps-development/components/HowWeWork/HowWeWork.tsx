import { FC } from 'react';
import Contents from '../../dtos/Contents.dto';
import Text from '../../styled/Text';
import Content from '../../dtos/Content.dto';
import Spacer from '../../styled/Spacer';

interface HowWeWorkProps {
  data: Contents;
}

const HowWeWork: FC<HowWeWorkProps> = ({ data }) => {
  return (
    <div className="container">
      <div className="row">
        <div className="col-12">
          {data.heading && (
            <Text fontSize="xxxl" fontFamily="montserrat" weight="bold">
              {data.heading}
            </Text>
          )}
        </div>
      </div>
      <Spacer size={20} direction={'vertical'} />
      <div className="row" style={{ gap: '2rem 0' }}>
        {data.content?.map((content: Content, index: number) => {
          return (
            <div className="col-md-4 col-12" key={index}>
              <div className="row">
                <div className="col-2 col-md-12">
                  <div className="row align-items-center">
                    <div className="col-md">
                      {content.icon && (
                        <img
                          width={80}
                          src={content.icon.sourceUrl}
                          alt={content.icon.title}
                        />
                      )}
                    </div>
                    <div className="col-md">
                      {data.content && index !== data.content?.length - 1 && (
                        <>
                          {/* TODO Refactor this to a single tag */}
                          <img
                            src={'https://i.ibb.co/tmRPzrZ/Group-243arrow.png'}
                            alt={'Arrow pointing to next block'}
                            style={{ transform: 'rotate(90deg)' }}
                            className="d-block d-md-none mt-4 mt-md-0"
                          />
                          <img
                            src={'https://i.ibb.co/tmRPzrZ/Group-243arrow.png'}
                            alt={'Arrow pointing to next block'}
                            className="d-none d-md-block"
                          />
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div className="col-10 col-md-8">
                  <Spacer size={10} direction={'vertical'} />
                  <Text
                    fontSize="md"
                    fontFamily="montserrat"
                    weight="semibold"
                    className="mb-3"
                  >
                    {content.title}
                  </Text>
                  <Text fontSize="sm"> {content.description} </Text>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default HowWeWork;
