import React from 'react';
import { useKeenSlider } from 'keen-slider/react';
import { TOptions } from 'keen-slider';

import { ArrowButton } from './KeenSlider.styled';

import 'keen-slider/keen-slider.min.css';

interface KeenSliderProps extends TOptions {
  children: React.ReactNode;
  showArrows?: boolean;
  slideTimer: Number;
}

const KeenSlider = ({ children, showArrows, ...props }: KeenSliderProps) => {
  const [pause, setPause] = React.useState(false);
  const timer = React.useRef();
  const [sliderRef, slider] = useKeenSlider({
    ...props,
    duration: 1000,
    dragStart: () => {
      setPause(true);
    },
    dragEnd: () => {
      setPause(false);
    },
  });

  React.useEffect(() => {
    sliderRef.current.addEventListener('mouseover', () => {
      setPause(true);
    });
    sliderRef.current.addEventListener('mouseout', () => {
      setPause(false);
    });
  }, [sliderRef]);

  React.useEffect(() => {
    timer.current = setInterval(() => {
      if (!pause && slider) {
        slider.next();
      }
    }, props.slideTimer);
    return () => {
      clearInterval(timer.current);
    };
  }, [pause, slider]);

  return (
    <div className="d-flex align-items-center" style={{ gap: '1rem' }}>
      {showArrows && (
        <ArrowButton onClick={() => slider.prev()} leftArrow>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#fff"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M19 12H6M12 5l-7 7 7 7" />
          </svg>
        </ArrowButton>
      )}
      <div
        ref={sliderRef as React.RefObject<HTMLDivElement>}
        className="keen-slider"
      >
        {children}
      </div>
      {showArrows && (
        <ArrowButton onClick={() => slider.next()} rightArrow>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#fff"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M5 12h13M12 5l7 7-7 7" />
          </svg>
        </ArrowButton>
      )}
    </div>
  );
};

interface KeenSlideProps {
  children: React.ReactNode;
}

export const KeenSlide = ({ children }: KeenSlideProps) => {
  return <div className="keen-slider__slide">{children}</div>;
};

export default KeenSlider;
