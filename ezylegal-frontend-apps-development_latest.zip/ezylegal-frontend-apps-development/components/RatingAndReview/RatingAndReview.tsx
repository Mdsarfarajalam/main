import React, { FC, useEffect, useState } from 'react';
import StarRatingComponent from 'react-star-rating-component';
import { useForm, Controller } from 'react-hook-form';
import { Modal } from 'react-bootstrap';
import StyledModal from '../../styled/StyledModal';
import Text from '../../styled/Text';
import Button from '../../styled/Button';
import ReactSelect from '../ReactSelect';
import countryCode from '../../constants/countryCode';
import Spacer from '../../styled/Spacer';

interface RatingAndReviewProps {}

interface RatingModalProps {
  show: boolean;
  setShow: any;
}

const RatingAndReview: FC<RatingAndReviewProps> = () => {
  const [rating, setRating] = useState<number>(0);

  const [feedbackData, setFeedbackData] = useState<string | null>(null);

  const onStarClick = (value: number) => {
    setRating(value);
  };

  const onStarHover = (value: number) => {
    setRating(value);
  };

  useEffect(
    function () {
      console.log(feedbackData);
    },
    [feedbackData]
  );

  const handleSubmit = () => {
    const formData = {
      rating,
      feedback: feedbackData,
    };

    console.log(formData);
  };

  return (
    <div className="">
      <div className=" mt-3">
        <Text fontSize="md" as="label" color="label" weight="semibold">
          Rate your Experience
        </Text>
        <div className="d-block" style={{ fontSize: '2rem' }}>
          <StarRatingComponent
            name="rate1"
            starCount={5}
            value={rating}
            starColor="#396AE8"
            emptyStarColor="gray"
            onStarClick={onStarClick}
            onStarHoverOut={onStarHover}
          />
        </div>
      </div>
      <Text
        fontSize="md"
        as="label"
        color="label"
        weight="semibold"
        className="mt-3"
      >
        Give Feedback
      </Text>
      <textarea
        className="form-control mb-4"
        onChange={(event) => {
          setFeedbackData(event.target.value);
        }}
      />
      <Button
        size={'md'}
        backgroundColor={'primary'}
        rounded={true}
        onClick={handleSubmit}
      >
        Submit Review
      </Button>
    </div>
  );
};

const RatingModal: FC<RatingModalProps> = ({ show, setShow }) => {
  const { control } = useForm({
    defaultValues: {
      countryCode: '91',
      mobile: '',
    },
  });
  return (
    <StyledModal as={Modal} show={show} onHide={() => setShow(false)}>
      <Modal.Header closeButton>
        <Text fontSize="xxl" fontFamily="montserrat" weight="bold">
          Submit your feedback
        </Text>
      </Modal.Header>

      <Modal.Body>
        <div>
          <input className="form-control" placeholder="Enter Name" />
        </div>
        <Spacer direction="vertical" size={10} />
        <div className="d-flex">
          <div style={{ width: '20%' }}>
            <Controller
              control={control}
              name="countryCode"
              render={({ field: { value, onChange, onBlur, ...field } }) => (
                <ReactSelect
                  getOptionValue={(option: any) => option.value}
                  options={countryCode}
                  placeholder=""
                  onBlur={onBlur}
                  value={countryCode.find((code) => code.value === value)}
                  onChange={(value: any) => {
                    onChange(value.value);
                  }}
                  {...field}
                />
              )}
            />
          </div>
          <Spacer direction="horizontal" size={10} />
          <div style={{ width: '80%' }}>
            <input
              className="form-control"
              placeholder="Enter valid mobile no."
            />
          </div>
        </div>

        <RatingAndReview />
      </Modal.Body>
    </StyledModal>
  );
};

export { RatingAndReview, RatingModal };
