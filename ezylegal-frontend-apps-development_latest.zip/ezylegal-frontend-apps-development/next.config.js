module.exports = {
    publicRuntimeConfig: {
        APP_NAME: process.env.APP_NAME, 
        RAZORPAY_KEY_ID: process.env.RAZORPAY_KEY_ID
    }
};